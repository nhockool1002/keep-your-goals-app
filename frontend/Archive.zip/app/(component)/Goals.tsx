import { lightTheme } from "@/constants/lightTheme";
import React, { useEffect } from "react";
import { View, Text, StyleSheet, FlatList, Dimensions } from "react-native";
import { ProgressBar } from "react-native-paper";
import moment from "moment";
import { Icon } from "react-native-elements";
import { color } from "react-native-elements/dist/helpers";

const screenWidth = Dimensions.get("window").width;

interface Goal {
  id: string;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  status: string;
  amount: number;
  current: number;
  type: string;
}

interface GoalsProps {
  goals: Goal[];
  theme: typeof lightTheme;
  t: (key: string) => string;
  i18n: any;
}

const getBackgroundColor = (type: string, theme: typeof lightTheme) => {
  switch (type) {
    case "SAVEMONEY":
      return theme.dstBgColorGoal;
    case "TODOQUANTITY":
      return theme.dstBgColorGoal;
    case "TODOANYTHING":
      return theme.dstBgColorGoal;
    default:
      return theme.dstBgColorGoal;
  }
};

const getStatusTextColor = (type: string) => {
  switch (type) {
    case "SAVEMONEY":
      return "#FFFFFF";
    case "TODOQUANTITY":
      return "#145A32";
    case "TODOANYTHING":
      return "#A04000";
    default:
      return "#FFFFFF";
  }
};

const calculateProgress = (current: number, amount: number) => {
  return amount > 0 ? Math.min(Math.round((current / amount) * 100), 100) : 0;
};

const formatDate = (date: string) => moment(date).format("DD-MM-YYYY");

const Goals: React.FC<GoalsProps> = ({ goals, theme, t, i18n }) => {
  return (
    <View style={[styles.container, { backgroundColor: theme.homeBgColor }]}>
      <FlatList
        data={goals}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          const progress = calculateProgress(item.current, item.amount);
          return (
            <View style={[styles.goalItem, { backgroundColor: getBackgroundColor(item.type, theme) }]}>

              <View style={[styles.containerTitle, { flexDirection: 'row', alignItems: 'center' }]}>
                <Icon
                  name="trophy-outline"
                  type="ionicon"
                  size={28}
                  color={
                    item.type === "SAVEMONEY" ? "#43e86a" : // Xanh lá đậm
                      item.type === "TODOQUANTITY" ? "#87CEEB" : // Xanh da trời
                        item.type === "TODOANYTHING" ? "#FF1493" : // Màu hồng
                          "gray" // Màu mặc định nếu không thuộc các loại trên
                  }
                  style={styles.icon}
                />
                <Text
                  style={[styles.title, { color: theme.goalTitleTextColor }]}
                  numberOfLines={1}
                  ellipsizeMode="tail"
                >
                  {item.title}
                </Text>
              </View>



              {/* Nội dung theo từng loại Goal */}
              {(item.type === "SAVEMONEY" || item.type === "TODOQUANTITY") && (
                <View style={styles.goalRow}>
                  <Text style={[styles.progressText, { color: theme.goalTitleTextColor }]}>
                    {item.current} / {item.amount}
                  </Text>
                  <Text style={[styles.dateText, { color: theme.primary }]}>
                    <Icon
                      name="today"
                      type="ionicon"
                      size={12}
                      color={
                        moment(item.endDate).isAfter(moment()) ? theme.calendarE :
                          moment(item.endDate).isSame(moment(), 'day') ? theme.calendarB :
                            theme.calendarO
                      }
                    />
                    {" " + formatDate(item.endDate)}
                  </Text>
                </View>
              )}


              {(item.type === "SAVEMONEY" || item.type === "TODOQUANTITY") && (
                <ProgressBar progress={progress / 100} color="#43e86a" style={styles.progressBar} />
              )}

              {item.type === "TODOANYTHING" && (
                <>
                  <View style={styles.goalRow}>
                    <Text style={[styles.description, { color: theme.primary }]}>
                      {item.description}
                    </Text>
                    <Text style={[styles.dateText, { color: theme.primary }]}>
                      <Icon
                        name="today"
                        type="ionicon"
                        size={12}
                        color={
                          moment(item.endDate).isAfter(moment()) ? theme.calendarE :
                            moment(item.endDate).isSame(moment(), 'day') ? theme.calendarB :
                              theme.calendarO
                        }
                      />
                      {" " + formatDate(item.endDate)}
                    </Text>
                  </View>
                  <View style={styles.statusContainer}>
                    {item.status === "TODO" && (
                      <View style={styles.statusInner}>
                        <View style={styles.statusRow}>
                          <Icon name="circle" type="feather" size={24} color="#995794" />
                          <Text style={[styles.statusText, { color: '#995794' }]}>{t('goal_status_todo')}</Text>
                        </View>
                      </View>
                    )}

                    {item.status === "IN_PROGRESS" && (
                      <View style={[styles.statusInner, styles.in_progress]}>
                        <View style={styles.statusRow}>
                          <Icon name="play-circle" type="feather" size={24} color="white" />
                          <Text style={[styles.statusText, { color: 'white' }]}>{t('goal_status_in_progress')}</Text>
                        </View>
                      </View>
                    )}

                    {item.status === "DONE" && (
                      <View style={[styles.statusInner, styles.completed]}>
                        <View style={styles.statusRow}>
                          <Icon name="check-circle" type="feather" size={24} color="green" />
                          <Text style={[styles.statusText, { color: 'green' }]}>{t('goal_status_done')}</Text>
                        </View>
                      </View>
                    )}
                  </View>
                </>
              )}
            </View>
          );
        }}
        ListEmptyComponent={<View style={[styles.container, { backgroundColor: theme.homeBgColor }]}><Text style={styles.noGoals}>{t("no_goals")}</Text></View>}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

export default Goals;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    paddingTop: 10,
    paddingBottom: 0,
  },
  goalItem: {
    width: screenWidth - 32,
    padding: 16,
    borderRadius: 10,
    marginBottom: 10,
    alignSelf: "center",
  },
  containerTitle: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10
  },
  icon: {
    marginRight: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
  },
  goalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 5,
  },
  progressText: {
    fontSize: 14,
    fontWeight: "bold",
  },
  dateText: {
    fontSize: 14,
    fontWeight: "light",
  },
  progressBar: {
    height: 6,
    borderRadius: 5,
    marginVertical: 5,
  },
  description: {
    fontSize: 14,
    marginTop: 5,
    width: 280,
  },
  status: {
    fontSize: 14,
    fontWeight: "bold",
    marginTop: 5,
  },
  noGoals: {
    textAlign: "center",
    marginTop: 20,
  },
  statusContainer: {
    flexDirection: "row",
    marginTop: 10,
  },
  statusInner: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 20,
    backgroundColor: "rgba(212, 212, 212, 0.85)",
    marginRight: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  completed: {
    backgroundColor: "rgba(192, 255, 210, 0.7)",
  },
  in_progress: {
    backgroundColor: "rgba(255, 187, 62, 0.7)",
  },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  statusText: {
    fontSize: 14,
    marginLeft: 5
  },
});
